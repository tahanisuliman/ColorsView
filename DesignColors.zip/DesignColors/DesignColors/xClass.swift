import UIKit

@IBDesignable public class isooView: UIView {
    
    @IBInspectable var firstColor: UIColor!{
        didSet{
            configureGradientLayer()
        }
    }
    @IBInspectable var secondColor: UIColor!{
        didSet{
            configureGradientLayer()
        }
    }
    @IBInspectable var thirdColor: UIColor!{
        didSet{
            configureGradientLayer()
        }
    }
    
    
    @IBInspectable var fourcolor: UIColor!{
        didSet{
            configureGradientLayer()
        }
    }
    
    
    
    
    override open class var layerClass: AnyClass {
        return CAGradientLayer.classForCoder()
    }
    
    required public init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
        configureGradientLayer()
    }
    
    public override init(frame: CGRect) {
        super.init(frame: frame)
        configureGradientLayer()
    }
    
    
    func configureGradientLayer() {
        let gradientLayer = layer as! CAGradientLayer
        gradientLayer.colors = [secondColor?.cgColor ?? UIColor.blue.cgColor, firstColor?.cgColor ?? UIColor.blue.cgColor   , thirdColor?.cgColor ?? UIColor.blue.cgColor  , fourcolor?.cgColor ?? UIColor.blue.cgColor  ] 
        gradientLayer.startPoint = CGPoint(x: 0.5, y: 0)
        gradientLayer.endPoint = CGPoint(x: 0.5, y: 1)
    }
}
